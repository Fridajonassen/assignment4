﻿// Frida Jonassen
// 08/11/2018

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    public enum FoodCategory
        {
            Meat,
            Vegeterian,
            Fish,
            SeaFood
        }
}
